from stk.random.random_ops import dense_mask, mask, randn
